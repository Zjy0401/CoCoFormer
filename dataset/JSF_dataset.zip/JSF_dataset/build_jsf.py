# -*-coding:utf-8-*-
import pickle5 as pickle
import numpy as np
import matplotlib.pyplot as plt
data = np.load('./js-fakes-16thSeparated.npz', allow_pickle=True, encoding='latin1')
data_pitches = data['pitches']
data_chords = data['chords']
chords_num = [0 for i in range(51)]
for i in data_chords:
    for j in i:
        chords_num[j] += 1
plt.figure(1)
plt.bar([i for i in range(48)], chords_num[:-3])
plt.show()
# analyse:

'''
to find the chords, analyse the pitches:
60 : middle C
51 bE 58 bB 63 bE 67 G
3 : bE
chords: major,minor,dim,aug 12*4 48
48,49:chord_rest chord_other? 
'''

'''
build new seqs:
one bar:
|S| |A| |T| |B|
[Bar(),Position(1/16),Chord(),Position(1/16),Note_On(),Note_Duration(),Position(),Note_On(),Note_Duration(),...,Bar()]
'''


# TODO: build new seqs
def build_event2word():
    '''
    build midi-events from datasets
    1) Track_start Track_end
    2) Bar
    3) Note-On
    4) Note-Velocity
    5) Note-Duration
    6) Position
    7) Chord
    '''

    event2word = {}
    # Note-on
    for i in range(128):
        key = 'Note-On_' + str(i)
        event2word[key] = i
    # Note-Duration:16th notes multiple
    for i in range(64):
        key = 'Note-Duration_' + str(i)
        event2word[key] = i
    # Position
    for i in range(16):
        key = 'Position_' + str(i)
        event2word[key] = i
    # Multi-Track build: (Bar)
    event2word['Bar'] = len(event2word)

    f = open('./event2word.pkl', 'wb')
    pickle.dump(event2word, f)
    f.close()

    return event2word


def build_word2event(event2word):
    # reverse the vector event2word
    word2event = {}
    for key, val in event2word.items():
        word2event[val] = key

    f = open('./word2event.pkl', 'wb')
    pickle.dump(word2event, f)
    f.close()

    return word2event


def build_training_seqs():
    pass


if __name__ == '__main__':
    event2word = build_event2word()
    word2event = build_word2event(event2word)

    print("done!")
